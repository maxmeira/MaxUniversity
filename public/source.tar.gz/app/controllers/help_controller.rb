class HelpController < ApplicationController
end
