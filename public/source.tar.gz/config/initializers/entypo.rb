Entypo.css_prefix = "entypo"
