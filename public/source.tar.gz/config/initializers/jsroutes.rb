JsRoutes.setup do |config|
  config.camel_case = true
  config.compact = true
end
